package com.example.start;

import android.content.Intent;

public class Notes {
    public String mTitle;
    public String mDetail;
    public int mInd;
    public Boolean mToggle;

    Notes(String title,String detail,int ind,Boolean toggle){
        this.mTitle = title;
        this.mDetail = detail;
        this.mInd = ind;
        this.mToggle = toggle;
    }
    public String getTitle(){
        return mTitle;
    }
    public String getDetail(){
        return mDetail;
    }
    public int getInd(){
        return mInd;
    }
    public Boolean getToggle(){
        return mToggle;
    }
}
